export class ClsTree {
 treeType:number;// 0= topdown, 1=middileout, 2= bottomup
 filename:string;
 chaptername:string;
 searchTerm:string;
 refTerm:string;
 sterm:string;
 sref:string;

}

