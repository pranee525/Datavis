 export class DataTree {


     public context!: string;
     
     public isActive!: Boolean;
     public reference!:string;
     public reference_end!:number;
     public reference_start!:number;
     public rel!:string;
     public rfc!:string;
     public resource!:string;
     public rid!:string;
     public toc1!:string;
     public toc2!:string
     public toc3!:string;
     public toc4!:string
     public toc5!:string;
     public toc6!:string
     public toc7!:string;
     public toc8!:string
     public toc9!:string;
     public toc10!:string
     public toc11!:string;
     public toc12!:string;
     public expanded:boolean=false;





}
