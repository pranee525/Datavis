import { DataTree } from './data-tree';

describe('DataTree', () => {
  it('should create an instance', () => {
    expect(new DataTree()).toBeTruthy();
  });
});
