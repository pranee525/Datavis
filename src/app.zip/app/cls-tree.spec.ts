import { ClsTree } from './cls-tree';

describe('ClsTree', () => {
  it('should create an instance', () => {
    expect(new ClsTree()).toBeTruthy();
  });
});
